<?php

	$con = mysqli_connect("localhost", "root", "", "manga");

	define("IVA", 1.06);

	define('NUM_POR_PAGINA',12);

	define('FRASES',["This one is so cool!", "I've heard great things about this!" , "My friend loves this one!", "I want to start reading this!", "This author is great!", "This cover is awesome!", "This one is on my top 10!", "I want to read this one too!", "You have great taste!"]);

?>