<div class="sub-footer">
	<a name="Bot">
	
	<div class="sub-1">
		<h2>Find us here</h2>

		<div class="mapa"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3112.110912001855!2d-9.154722!3d38.738217!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd19330e712817b5%3A0x74bd153596f269b3!2sAv.+de+Berna+52A%2C+1050-099+Lisboa!5e0!3m2!1spt-PT!2spt!4v1513985062240" width="100%" height="280" frameborder="0" style="border:0" allowfullscreen></iframe></div>
	</div>

	<div class="sub-2">
		
		<div class="caixa-2"> 
			<h2>Newsletter</h2>

		<input class="newsletter" type="text" name="email" placeholder="Your Email">
		<button type="submit" name="submitNewsletter" class="newsbtn">
        <span>Submit</span>
        </button>

		<!--
		<div class="caixa-2"> 
			<h2>Contact us</h2>

			<form action="enviar_email.php" method="POST">
	 	  		<ul>
			 	  	<li><input type="text" name="nome" placeholder="Name"> </li>
			 	  	<li><input type="text" name="mail" placeholder="Email"> </li>
			 	  	<li><input type="text" name="assunto" placeholder="Subject"> </li>
			 	  	<li><textarea name="texto"></textarea></li>
			        <li><input type="submit" value="Submit" class="reg-enviar"> </li>
			 	</ul>
			</form>
		-->

			<!--<textarea name="sugestao" id="sugestao"></textarea><br>
			<input placeholder="Your Email" type="email" name="email" id="email" size="25">
			<button onclick="enviar()">Submit</button>-->
	</div>

	<div class="caixa-2"> 
		 
		<h2 class="follow-h">Follow us on</h2>
		<a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter" id="twitter" aria-hidden="true" title="Twitter"></i></a><br>
		<a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook-square" id="facebook" aria-hidden="true" title="Facebook"></i></a><br>
		<a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram" id="instagram" aria-hidden="true" title="Instagram"></i></a><br>
	

	</div>

</div>
	

</div>

<div class="footer">	

	<div class="info-a"> 
		<h3>Our store</h3>
		<div class="sub-info">
			Av. de Berna, 52A <br> 
			1050-099 Lisbon <br>
			Portugal <br> 
		</div>

		<h3>Schedule</h3>
		<div class="sub-info">
			Monday to Saturday <br>
			10 AM to 10 PM 
		</div>
	</div>

	<div class="info-b"> 
		<h3>Contacts</h3>
		<div class="sub-info">
			thepandabookshop@gmail.com <br> 
			+(351) 213 456 789 <br>
			+(351) 919 876 543 <br> 
		</div>
	</div>

	
	<div class="info-c"> 
		<h3>Info</h3>
		<div class="sub-info">
			Mangaka of the Month changes on <br> the 7th of every month / <br> Orders over 100€ will benefit of <br> a 5% discount
			
		 </div>
		<!--
		<a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter" id="twitter" aria-hidden="true" title="Twitter"></i></a><br>
		<a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook-square" id="facebook" aria-hidden="true" title="Facebook"></i></a><br>
		<a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram" id="instagram" aria-hidden="true" title="Instagram"></i></a><br>
		-->
	</div>

<div class="backtotop">	
	<a href="#Top" class="top"><i class="fa fa-chevron-circle-up" aria-hidden="true"></i></a>

</div>
	
</div>