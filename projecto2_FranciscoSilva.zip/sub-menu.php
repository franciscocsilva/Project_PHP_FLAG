<div class="acc-menu">	
	<ul>
		<li><a href="index.php?area=carrinho"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span>Your Cart</span></a></li>
		<li><a href="index.php?area=wishlist"><i class="fa fa-heart" aria-hidden="true"></i><span>Wishlist</span></a></li>
	</ul>
</div>